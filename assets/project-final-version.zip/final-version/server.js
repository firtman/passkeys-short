import express from 'express'
import { Low } from 'lowdb'
import { JSONFile } from 'lowdb/node'
import * as url from 'url';
import bcrypt from 'bcryptjs';
import * as SimpleWebAuthnServer from '@simplewebauthn/server';
import session from 'express-session';


/****************
 * WEBAUTH CONFIG RELYING PARTY (RP) VARIABLES
 ****************/
const rpName = "Coffee Masters"
const rpID = "localhost";
const protocol = "http";
const port = 5050;
const expectedOrigin = `${protocol}://${rpID}:${port}`;
// Note: it's now possible to have an array of rpIDs and expected origins following multi-origin specs

/****************
 * DATA STORAGE SET UP
 ****************/
const __dirname = url.fileURLToPath(new URL('.', import.meta.url));
const adapter = new JSONFile(__dirname + '/auth.json');
const db = new Low(adapter);
await db.read();
db.data ||= { users: [] }

/****************
 * EXPRESSJS SERVER SETUP
 ****************/
const app = express()
app.use(express.json())

app.use(express.static('public'));
app.use(express.json());
app.use(express.urlencoded({
  extended: true
}));

app.use(session({
    secret: "a very strong secret key",  // Change this to a strong secret
    resave: false,
    saveUninitialized: true,
    cookie: { secure: false }   // Set true if using HTTPS
}));


/****************
 * STANDARD LOGIN SERVICES 
 ****************/

function findUser(email) {
    const results = db.data.users.filter(u=>u.email==email);
    if (results.length==0) return undefined;
    return results[0];
}

app.post("/auth/register", (req, res) => {
    var salt = bcrypt.genSaltSync(10);
    var hash = bcrypt.hashSync(req.body.password, salt);

    const user = {
        name: req.body.name,
        email: req.body.email,
        password: hash
    };
    const userFound = findUser(req.body.email);

    if (userFound) {
        // User already registered
        res.send({ok: false, message: 'User already exists'});
    } else {
        // New User
        db.data.users.push(user);
        db.write();
        res.send({ok: true});
    }
});

app.post("/auth/login", (req, res) => {
    const user = findUser(req.body.email);
    if (user) {
        // user exists, check password
        if (bcrypt.compareSync(req.body.password, user.password)) {
            res.send({ok: true, email: user.email, name: user.name});
        } else {
            res.send({ok: false, message: 'Your login credentials are invalid.'});            
        }
    } else {
        // User doesn't exist
        res.send({ok: false, message: 'Your login credentials are invalid.'});
    }
});


app.post("/auth/auth-options", (req, res) => {
    const user = findUser(req.body.email);    

    if (user) {
        res.send({
            password: true,
            webauthn: user.webauthn
        })
    } else {
        res.send({
            password: true
        })
    }
});

/****************
 * WEBAUTH PASSKEY REGISTRATION SERVICES
 ****************/
app.post("/auth/webauth-registration-options", async (req, res) =>{
    try {
        const user = findUser(req.body.email);

        const options = {
            rpName,
            rpID,
            userName: user.name,
            attestationType: 'none', // Better UX, Don't prompt users for additional information about the authenticato

            // Optional, Prevent users from re-registering existing authenticators
            // excludeCredentials: user.passkeys ? user.passkeys.map(pk => ({
            //     id: pk.credentialID,
            //     transports: pk.transports,
            // })) : [],

            authenticatorSelection: {
                // Defaults
                residentKey: 'preferred',
                userVerification: 'preferred',
                // Optional
                // authenticatorAttachment: 'platform', // platform or cross-platform
                // Optional
                // preferredAuthenticatorType: '', // securityKey, localDevice, remoteDevice
            },
        };

        /**
         * The server needs to temporarily remember this value for verification, so don't lose it until
         * after you verify an authenticator response.
         */
        const regOptions = await SimpleWebAuthnServer.generateRegistrationOptions(options)
        user.currentChallenge = regOptions.challenge;
        db.write();   
        
        // Send response to the client
        res.send(regOptions);
    } catch (e) {
        res.status(500);
    }
});

app.post("/auth/webauth-registration-verification", async (req, res) => {
    const user = findUser(req.body.user.email);
    const data = req.body.data;
    
    let verification;
    try {
      const options = {
        response: data,
        expectedChallenge: user.currentChallenge,
        expectedOrigin,
        expectedRPID: rpID,
        requireUserVerification: true,
      };
      verification = await SimpleWebAuthnServer.verifyRegistrationResponse(options);
    } catch (error) {
        console.log(error);
      return res.status(400).send({ error: error.toString() });
    }
  
    const { verified, registrationInfo } = verification;  

    if (verified && registrationInfo) {     
  
      const existingPasskey = user.passkeys ? user.passkeys.find(
        passkey => passkey.id == registrationInfo.credential.id
      ) : false;
  
      if (!existingPasskey) {
        const newPasskey = registrationInfo.credential;
        if (user.passkeys==undefined) {
            user.passkeys = [];
        }
        user.webauthn = true;
        user.passkeys.push(newPasskey);
        db.write();
      }
    } else {
        console.log("Passkey already stored.")
    }
  
    res.send({ ok: true });

});

/****************
 * WEBAUTH PASSKEY AUTHENTICATION (LOGIN) SERVICES
 ****************/
app.post("/auth/webauth-login-options", async (req, res) =>{
    const user = findUser(req.body.email);
    if (user==null) {
        // User not found, it's maybe a conditional UI query
        // res.sendStatus(404);
        // return;
    }
    const options = {
        allowCredentials: user && user.passkeys ? user.passkeys.map(passkey => ({
          id: passkey.id,
          transports: passkey.transports,
        })) : [],
        userVerification: 'required',
        rpID,
    };
    const loginOpts = await SimpleWebAuthnServer.generateAuthenticationOptions(options);
    if (user) {
        user.currentChallenge = loginOpts.challenge;
        db.write();
    } else {
        req.session.webauthnChallenge = loginOpts.challenge;;
    }
    res.send(loginOpts);
});


app.post("/auth/webauth-login-verification", async (req, res) => {
    const data = req.body.data;
    let user = findUser(req.body.email);
    if (user==null) {
        // User not found, it's maybe a conditional UI query

        // Uncomment if you won't support conditional UI
        // res.sendStatus(400).send({ok: false});
        // return;        
    } 
  
    const expectedChallenge = user ? user.currentChallenge : req.session.webauthnChallenge;
  
    let registeredPasskey;
    const { id } = data;

    let candidates;
    if (user) {
        candidates = [user]; // Just the current user
    } else {
        candidates = db.data.users;
    }

    // Find passkeys on candidate users         
    for (const candidate of candidates) {
        for (const passkey of candidate.passkeys) {
            if (passkey.id == id) {
                registeredPasskey = passkey;
                user = candidate;
                break;
            }
        }
    }

    if (!registeredPasskey) {
      return res.status(400).send({ ok: false, message: 'Passkey is not registered with this site' });
    } 
  
    // Verifies the passkey
    let verification;
    try {
      const options  = {
        response: data,
        expectedChallenge: expectedChallenge,
        expectedOrigin,
        expectedRPID: rpID,
        credential: {
            id: registeredPasskey.id,
            publicKey: Buffer.from(Object.values(registeredPasskey.publicKey)), // converts it back into a Buffer
            counter: registeredPasskey.counter,
            transports: registeredPasskey.transports,
        },        
        requireUserVerification: true,
      };
      verification = await SimpleWebAuthnServer.verifyAuthenticationResponse(options);
    } catch (error) {
      console.log(error);
      return res.status(400).send({ ok: false, message: error.toString() });
    }
  
    const { verified, authenticationInfo } = verification;
  
    if (verified) {
      registeredPasskey.counter = authenticationInfo.newCounter;
      db.write();
    }
  
    // Send response to the client
    res.send({ 
        ok: true, 
        user: {
            name: user.name, 
            email: user.email
        }
    });
});

/****************
 * EXPRESS JS SET UP
 ****************/

app.get("*", (req, res) => {
    res.sendFile(__dirname + "public/index.html"); 
});

app.listen(port, () => {
  console.log(`App listening on port ${port}`)
});

