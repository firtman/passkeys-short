import Router from './Router.js';
import Auth from './Auth.js';

window.addEventListener("DOMContentLoaded", () => {
    Router.init();
 } );

